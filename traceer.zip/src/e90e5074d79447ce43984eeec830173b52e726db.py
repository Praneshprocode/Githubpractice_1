

from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser =p.chromium.launch(headless=False)
    context =browser.new_context()
    context.tracing.start(
        screenshots=True,
        sources= True,
        snapshots= True
    )
    page =context.new_page()
    page.goto("https://omayo.blogspot.com/")
    page.locator('(//input[@type="text"])[2]').fill("Praneshwar")
    context.tracing.stop(path="traceer.zip")
    browser.close()
